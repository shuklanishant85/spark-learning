package com.amex.training.sparksql;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;

public class DataSetWriteWithJDBCTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SparkSession spark=SparkSession.builder().appName("dataframe-test")
				.master("local[*]").getOrCreate();
		spark.sparkContext().setLogLevel("WARN");
		Dataset<Row> ds=spark.read().format("csv")
				.option("header", true)
				.load("c:/test/employee.csv");
		
		
		ds.where("designation='Developer'").write().
		format("jdbc").option("url", "jdbc:mysql://localhost:3306/trainingdb")
		.option("dbtable","developers").
		mode(SaveMode.Append)
		.option("user","root").option("password","rps@12345")
		.save();

	}

}
